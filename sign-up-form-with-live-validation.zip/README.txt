A Pen created at CodePen.io. You can find this one at https://codepen.io/chrissteurer/pen/oqjul.

 A simple sign up form that uses stationery float labels for usability and uses jquery to live validate the password information.